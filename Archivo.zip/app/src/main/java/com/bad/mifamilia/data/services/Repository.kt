package com.bad.mifamilia.data.services

import com.bad.mifamilia.data.services.models.StagesPovider
import com.bad.mifamilia.models.Etapa

class Repository {
    private val api = repoServices()

    suspend fun getAllStages(id: Int, id_user : Int, page: Int, perPage : Int): List<Etapa>{
        val response: List<Etapa> = api.getStages(id,id_user,page,perPage)
        StagesPovider.iStages = response
        return response
    }
}