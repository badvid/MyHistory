package com.bad.mifamilia.data.services.models

import com.bad.mifamilia.models.Etapa

class StagesPovider {
    companion object {
        var iStages : List<Etapa> = emptyList()
    }
}