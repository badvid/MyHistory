package com.bad.mifamilia.data.services.models

data class UserLogin (
    val user : String,
    val pass: String
)