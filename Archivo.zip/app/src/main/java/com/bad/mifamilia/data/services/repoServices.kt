package com.bad.mifamilia.data.services

import com.bad.mifamilia.helpers.RetrofitHelper
import com.bad.mifamilia.models.Etapa
import com.bad.mifamilia.data.services.models.StageGetResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

class repoServices {

    private val retrofit = RetrofitHelper.getInstance()

    suspend fun  getStages(id: Int, id_user : Int, page: Int, perPage : Int): List<Etapa> {
        return withContext(Dispatchers.IO){
            val response : Response<StageGetResponse> = retrofit.getStages(id,id_user,page,perPage)
            response.body()!!.data ?: emptyList()
           /* if(response.isSuccessful)
            {
                if(response.body()!!.success) g.iStages = response.body()!!.data

            }*/
        }
    }
}