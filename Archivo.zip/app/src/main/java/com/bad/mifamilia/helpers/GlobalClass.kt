package com.bad.mifamilia.helpers

import android.app.Application
import android.content.Context
import android.graphics.drawable.Drawable
import androidx.lifecycle.MutableLiveData
import com.bad.mifamilia.adapters.EtapaAdapter
import com.bad.mifamilia.adapters.FamilyAdapter
import com.bad.mifamilia.adapters.GaleryAdapter
import com.bad.mifamilia.data.services.models.GalleryPostResponse
import com.bad.mifamilia.models.*
import java.io.ByteArrayInputStream
import java.io.IOException
import java.util.*

public final class GlobalClass : Application {

    private var Url: String? = null
    private val apiKey = "U0lTTE9HQlM7UzEzTDA1OVIwRA=="
    public var oUsu: User? = null
    public var iStages: List<Etapa> = listOf<Etapa>()
    public var iGalleries: List<Galeria> = listOf<Galeria>()
    public var oStage : Etapa? = null
    public var oGallery : Galeria? = null
    var isAddScan = false
    public var iFamily: List<Family> = listOf<Family>()
    public var iParents: List<Parent> = listOf<Parent>()


    public lateinit var etapaAdapter : EtapaAdapter
    public lateinit var galeryAdapter : GaleryAdapter
    public lateinit var familyAdapter : FamilyAdapter
    constructor() { //oPedBuscar = new PedidoSearch();
    }

    /*constructor(IP: String?) {
        iP = IP
        //Apellido = apellido;
        //Nombre = nombre;
        //Foto = foto;
        //oPedBuscar = new PedidoSearch();
    }

    fun decodeDrawable(context: Context, base64: String): Drawable? {
        var ret: Drawable? = null
        if (base64 != "") {
            val bais = ByteArrayInputStream(
                Base64.decode(base64.toByteArray(), Base64.DEFAULT)
            )
            ret = Drawable.createFromResourceStream(
                context.getResources(),
                null, bais, null, null
            )
            try {
                bais.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        return ret
    }*/

}