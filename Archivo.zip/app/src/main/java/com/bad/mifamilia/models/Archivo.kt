package com.bad.mifamilia.models

data class Archivo (var id :Int, var nombre:String, var extension :String, var tamanio:String, var ubicacion : String)