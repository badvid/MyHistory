package com.bad.mifamilia.ui.family

import androidx.lifecycle.ViewModel

class FamilyViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}