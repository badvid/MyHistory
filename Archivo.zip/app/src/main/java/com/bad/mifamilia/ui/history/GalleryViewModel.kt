package com.bad.mifamilia.ui.history

import androidx.lifecycle.ViewModel

class GalleryViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}