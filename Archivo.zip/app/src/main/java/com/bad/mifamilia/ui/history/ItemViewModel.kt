package com.bad.mifamilia.ui.history

import androidx.lifecycle.ViewModel

class ItemViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}