package com.bad.mifamilia.ui.history

import androidx.lifecycle.ViewModel

class MultimediaViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}